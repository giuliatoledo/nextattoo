<?php

include "conexao.php";

//Resgata os valores do formulário
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$regiao = isset($_POST['regiao']) ? $_POST['regiao'] : null;
$email = isset($_POST['email']) ? $_POST['email'] : null;
$senha = isset($_POST['senha']) ? $_POST['senha'] : null;
$id = isset($_POST['id']) ? $_POST['id'] : null;

// validação (bem simples, mais uma vez)
if (empty($nome) || empty($regiao) || empty($email) || empty($senha))
{
    echo "Volte e preencha todos os campos";
    exit;
}

// atualiza o banco
$PDO = db_connect();
$sql = "UPDATE usuarios SET nome = :nome, regiao =:regiao, email = :email, senha = :senha WHERE id = :id";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':nome', $nome);
$stmt->bindParam(':regiao', $regiao);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':senha', $senha);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);

if ($stmt->execute())
{
    header('Location: ../front/inicial.php');
}
else
{
    echo "Erro ao alterar";
    print_r($stmt->errorInfo());
}

?>
