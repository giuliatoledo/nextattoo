<?php

/**
 * Conecta com o MySQL usando PDO
 */
function db_connect()
{
    $PDO = new PDO('mysql:host=' . 'localhost' . ';dbname=' . 'database' . ';charset=utf8', 'root', '');
    return $PDO;
}
    return false;
?>
