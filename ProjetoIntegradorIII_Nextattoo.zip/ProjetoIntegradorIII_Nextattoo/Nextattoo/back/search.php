<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Nextattoo</title>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="../img/fav.jpg" type="image/x-icon"/>
    <link rel="stylesheet" type="text/css"  href="../css/nextattoo.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
</html>
<?php
include "./conexao.php";

$PDO = db_connect();
$sql = "SELECT nome, regiao, email, senha FROM usuarios WHERE search=:regiao";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();

$search

$users = $stmt->fetch(PDO::FETCH_ASSOC);
?>


