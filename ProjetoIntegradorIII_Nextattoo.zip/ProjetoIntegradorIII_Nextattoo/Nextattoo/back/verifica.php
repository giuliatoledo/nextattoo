 <?php
	$bd=include "back/conexao.php";
		// check opção escolhida

 $display = 'none';
 
 if(isset($_POST['email']) && ($_POST['senha'])){
     
 $post_email = $_POST['email'];
 $post_senha = $_POST['senha'];    
  try{
      $bd=include "pdo.php";
    $pdo=new PDO($bd)
  }catch(PDOException $e){
      echo $e->getMessage();
      exit(1);
  }
  $stmt = $pdo->prepare("SELECT email,nome,senha,regiao FROM acesso 
  WHERE usuario = :nome or regiao=:regiao or email=:email and senha=:senha");
$stmt->bindparam(':login', $post_login, PDO::PARAM_STR);
$stmt->execute();
$linha = $stmt->fetchObject();
?>