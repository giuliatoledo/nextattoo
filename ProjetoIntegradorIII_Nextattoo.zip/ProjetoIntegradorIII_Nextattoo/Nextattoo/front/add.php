<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Nextattoo</title>
  <link rel="shortcut icon" href="../img/fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css"  href="../css/style.css"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">	
    <body>
    <center>
	<header><img class="logotipo" src="../img/nxt.png"></header><h3><font-color:white><br><br>

<?php

include "../back/conexao.php";

//Pega dados do formulário
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$regiao = isset($_POST['regiao']) ? $_POST['regiao'] : null;
$email = isset($_POST['email']) ? $_POST['email'] : null;
$senha = isset($_POST['senha']) ? $_POST['senha'] : null;

//Validar para evitar dados vazios
if (empty($nome) || empty($regiao) || empty($email) || empty($senha)) {
	echo "Ops! Não se esqueça de preencher todos os campos :)";
	exit;
}

//Insere no banco

$sql = "INSERT INTO usuarios(nome, regiao, email, senha) VALUES (:nome, :regiao, :email, :senha)";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':nome',$nome);
$stmt->bindParam(':regiao', $regiao);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':senha', $senha);

if ($stmt->execute()) {
	header('Location: acessologin.php');
} else {
	echo "Erro ao cadastrar";
	print_r($stmt->errorInfo());
}

?>

</body>
</head>
</html>