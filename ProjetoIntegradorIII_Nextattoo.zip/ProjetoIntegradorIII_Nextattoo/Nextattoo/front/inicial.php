<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Nextattoo</title>
	<meta charset="utf-8">
    <link rel="shortcut icon" href="../img/fav.jpg" type="image/x-icon"/>
	<link rel="stylesheet" type="text/css"  href="../css/nextattoo.css">
  	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	
	<link href="css/bootstrap.min.css" rel= "stylesheet" type="text/css"/>
	<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type= "text/javascript" src="js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

<body class="body">
<div class="layout">
<header><img class="logotipo"  src="../img/nextattologopreto.jpg" height="50px"></header>

<div class="container" style="margin-left: 0%;">
  <div class="row" >
  <script>
	$(document).ready(function(){
		//requisição http
		let url ="http://rafaelsperoni.pro.br/tsi/menus.php?user=2018003605"
		$.getJSON(url, function(dados){
		//dados é um array com o conteúdo do json
		console.log(dados);
		for (i=0; i<8; i++){
					$("#lista-menu").append('<li><a href="'+dados[i].link+'" id="'+dados[i].titulo+'">'+dados[i].titulo+'</a></li>');
				}
	});
	});
	</script>
    
    	<div class="menu-buttons">
      <section>
        <nav id="menu" align="center">
        <ul id="lista-menu">
		</ul>
</div>
    <div class="col">
	
    </div>
    <div class="col-8" style="padding-left: 8%;" >
	<div id="menu-buttons" >
        <article style="width:150%" >

          <?php
include "../back/conexao.php";

//SQL para contar o total de registros
$sql_count = "SELECT COUNT(*) AS total FROM usuarios ORDER BY nome ASC";

//SQL para selecionar os registros
$sql = "SELECT id, nome, regiao, email, senha FROM usuarios ORDER BY nome ASC";

//Conta o total de registros.
$stmt_count = $PDO->prepare($sql_count);
$stmt_count->execute();
$total = $stmt_count->fetchColumn();

//Seleciona os registros
$stmt = $PDO->prepare($sql);
$stmt->execute();

?>
<center><br><br>
<h2><font color='white'>Lista de Usuários</h2><br>
<button type="button" class="btn btn-danger"><a href="form-action.php"><font color='white'>Adicionar novo</font></a>
</button><br><br>
	<?php if ($total > 0): ?>

		<table width="100%" border="0">
			<thead>
				<tr>
					<th>Nome</th>
					<th>Estado</th>
					<th>Email</th>
					<!--<th>Senha</th>-->
				</tr>
			</thead>
			<tbody>
				<?php while ($user = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
					<tr>
			<td><?php echo $user['nome'] ?></td>
						<td><?php echo $user['regiao'] ?></td>
	                    <td><?php echo $user['email'] ?></td>
	               	 	<!--<td><?php echo $user['senha'] ?></td>-->

	               	 	<td><button type="button" class="btn btn-danger"><a href="form-edit.php?id=<?php echo $user['id'] ?>"><font color='white'>Editar</font></a></button></td>

	               	 	<td><button type="button" class="btn btn-danger"><a href="delete.php?id=<?php echo $user['id'] ?>" onclick="return confirm('Tem certeza de que deseja remover?');"><font color='white'>Remover</font></a></button></td>
                    </tr>				
	<?php endwhile; ?>
			</tbody>
		</table>
	<?php else: ?>				
        <p>Nenhum usuário registrado</p>
    <?php endif; ?><br>
</font>
<p>Total de Usuários: <?php echo $total ?></p>
<!--
<BR><form action="../back/search.php"><TR>
        <label for="search">
        <input class="form-control mr-sm-2" type="search" placeholder="Pesquisar" aria-label="Pesquisar">
  		<button class="btn btn-danger" type="submit" name="search" id="search" value="Buscar">Pesquisar</button>
  		</label>
    </form>
 <br><br>-->
   </article>
	</div>
	</div>
		</nav>
</section>    
    </div>
	</div>

      <footer>
        <p>© 2019 The Nextattoo Company, all rights reserved</p>
      </footer>
    
</body>
</head>
</html>