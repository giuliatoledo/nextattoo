<?php include "../back/conexao.php"; ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
  <title>Nextattoo</title>
  <link rel="shortcut icon" href="../img/fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css"  href="../css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <center>
  <img class="logotipo" src="../img/nxt.png">
</head>

  <body>

		 <?php
		// check opção escolhida
		    echo "<font color='white'><h5>Para realizar o cadastro é rapidinho! :)<br>Preencha as informações abaixo:</font></h5><br>";

		?>

<!--
<div class="container">
  <div class="row">
    <div class="col-sm">
     <form action="add.php" method="POST">
      <div class="form-group">
          <label for="nome">Nome</label><input type="text" name="nome" id="nome" class="form-control" aria-describedby="Name" placeholder="Seu nome" style=" width: 300px;">
        </div>

        <div class="form-group">
          <label for="regiao">Estado</label><input type="text" name="regiao" id="regiao" class="form-control" placeholder="Estado" style=" width: 100px;">
        </div>-->

<div class="container">
  <div class="row">
    <div class="col-sm">
     <form action="add.php" method="POST">
    <div class="form-row">
    <div class="form-group col-md-4">
      <label for="nome">Nome</label>
      <input type="text" name="nome" id="nome" class="form-control" aria-describedby="Name" placeholder="Seu nome" style=" width: 205px;"></div>

    <div class="form-group col-md-1">
      <label for="regiao">Estado</label>
      <input type="text" name="regiao" id="regiao" class="form-control" placeholder="Estado" style=" width: 75px";></div>
    </div>

        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="text" name="email" id="email" class="form-control" aria-describedby="emailHelp" placeholder="Seu email" style=" width: 300px;">
        </div>

        <div class="form-group">
          <label for="senha">Senha</label>
          <input type="password" name="senha" id="senha" class="form-control" placeholder="Senha" style=" width: 300px;">
        </div>

        <div class="form-group form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Lembrar Dados de Acesso</label>
        </div><br>
      <button type="submit" input class="btn btn-primary">Cadastrar</button>
      </form>
  	</div>
</div>	

</body>
</head>
</html>