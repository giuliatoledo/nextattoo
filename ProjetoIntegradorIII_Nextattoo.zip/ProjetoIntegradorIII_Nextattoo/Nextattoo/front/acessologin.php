<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Nextattoo</title>
  <link rel="shortcut icon" href="img/fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css"  href="../css/style.css"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">	
    <body>
    <center>
	<header><img class="logotipo" src="../img/nxt.png"></header>

		 <?php
 echo "<font color='white'><h4>Quase lá... <br>#FindYourNextattoo</font></h4><br>";
		?>

<div class="container">
  <div class="row">
    <div class="col-sm">
     <form action="inicial.php" method="POST">
        <div class="form-group">
          <label for="exampleInputEmail1">E-mail</label>
          <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu email" style=" width: 300px;">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Senha</label>
          <input type="password" name="senha" class="form-control" id="exampleInputPassword1" placeholder="Senha" style=" width: 300px;">
        </div>
        <div class="form-group form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Lembrar Dados de Acesso</label>
        </div><br>
    </div>
</div>  

<div class="d-flex justify-content-center">
  <button type="submit" input class="btn btn-primary" name="login">Login</button></form><Br>
  <form action="form-action.php" method="POST">
      <button type="submit" input class="btn btn-primary">Cadastrar</button></form> 
</div>

</body>
</head>
</html>