<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
  <title>Nextattoo</title>
  <link rel="shortcut icon" href="../img/fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css"  href="../css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <center>
  <img class="logotipo" src="../img/nxt.png">
</head>

<body>

<div class="container">
  <div class="row">
    <div class="col">
          <h3> Seja bem-vindo a Nextattoo! <br></h3>
          <h6>Diga-nos o que você está procurando.</h6><br>

<!--Botões para escolher entre tatuador e cliente-->

    </div>
  </div>

  <div class="row">
      <div class="col">
        <button type="button" class="btn btn-danger"><a href="acesso.php?tatuador=sim"><font color='white'> Sou tatuador!</font></a></button>
      </div>
  </div>

    <div class="row">
      <div class="col">
        <button type="button" class="btn btn-danger"><a href="acesso.php?tatuador=não"><font color='white'>Sou cliente e quero achar minha <b>#NEXTATTOO!</b>
        </font></a></button>
      </div>
  </div>

</div>

</body>
</html>

