<?php
include "../back/conexao.php";

//SQL para contar o total de registros
$sql_count = "SELECT COUNT(*) AS total FROM usuarios ORDER BY nome ASC";

//SQL para selecionar os registros
$sql = "SELECT id, nome, regiao, email, senha FROM usuarios ORDER BY nome ASC";

//Conta o total de registros.
$stmt_count = $PDO->prepare($sql_count);
$stmt_count->execute();
$total = $stmt_count->fetchColumn();

//Seleciona os registros
$stmt = $PDO->prepare($sql);
$stmt->execute();

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
		<meta charset="utf-8">
	<title>Nextattoo</title>
  <link rel="shortcut icon" href="../img/fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css"  href="../css/style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <center>
  <img class="logotipo" src="../img/nxt.png">
</head>

  <body>

	<h2><font color='white'>Lista de Usuários</h2><br>

	<button type="button" class="btn btn-danger"><a href="form-action.php"><font color='white'>Adicionar novo</font></a></button>
	<br>

	<?php if ($total > 0): ?>

		<table width="50%" border="0">
			<thead>
				<tr>
					<th>Nome</th>
					<th>Email</th>
					<!--<th>Senha</th>-->
				</tr>
			</thead>
			<tbody>
				
				<?php while ($user = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
					<tr>
			<td><?php echo $user['nome'] ?></td>
	                    <td><?php echo $user['email'] ?></td>
	                   <!-- <td><?php echo $user['senha'] ?></td>-->
	                    <td><a href="form-edit.php?id=<?php echo $user['id'] ?>"><font color='white'>Editar</a><br></td>
                        <td> <a href="delete.php?id=<?php echo $user['id'] ?>" onclick="return confirm('Tem certeza de que deseja remover?');"><font color='white'>Remover</a></td>
                    </tr>				
	<?php endwhile; ?>
			</tbody>
		</table>
	<?php else: ?>				
        <p>Nenhum usuário registrado</p>
    <?php endif; ?><br>
<p>Total de Usuários: <?php echo $total ?></p>

</body>
</html>
